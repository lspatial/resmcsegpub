"""
This module (data) provides a image for tests. See details for imgload function.

"""

from resmcseg.data.dataload import aimgload as dload